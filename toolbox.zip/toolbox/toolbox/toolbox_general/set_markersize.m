function set_markersize(hh, ms)

set(hh, 'MarkerSize', ms);